﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ödevv1
{
    public partial class Form1 : Form
    {
        // Kontrollere estetik yuvarlak köşeler eklemek için Windows API kullanımı
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse
        );

        // Renk Paleti (Ekran görüntüsündeki tonlar)
        private Color renkAnaArkaPlan = Color.FromArgb(245, 247, 250);
        private Color renkSidebar = Color.FromArgb(28, 35, 43); // Daraltılmış koyu sol panel
        private Color renkYaziBeyaz = Color.FromArgb(255, 255, 255);
        private Color renkYaziKoyu = Color.FromArgb(44, 62, 80);
        private Color renkKenarlik = Color.FromArgb(226, 232, 240);

        // Form Bileşenleri
        private Panel panelSidebar;
        private Panel panelHeader;
        private Panel panelMainContent;
        private Label lblBaslik;
        private DataGridView dgvHastalar;

        // Girdi Kontrolleri
        private TextBox txtTC, txtAdSoyad, txtEposta, txtTelefon;
        private ComboBox cmbCinsiyet, cmbKanGrubu, cmbPoliklinik;
        private DateTimePicker dtpDogumTarihi;
        private Button btnKaydet, btnGuncelle, btnSil;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // --- FORM GENEL AYARLARI ---
            this.Size = new Size(1250, 780);
            this.Text = "Hastanem | Dijital Hasta Kayıt ve Yönetim Sistemi";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = renkAnaArkaPlan;
            this.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point);

            // --- 1. SIDEBAR (Sol Menü Paneli - Görseldeki gibi daraltıldı) ---
            panelSidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 180, // İstediğin gibi daraltıldı
                BackColor = renkSidebar
            };

            // Logo Alanı
            Label lblLogo = new Label
            {
                Text = "🏥 HASTANEM",
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = renkYaziBeyaz,
                Location = new Point(15, 25),
                AutoSize = true
            };
            panelSidebar.Controls.Add(lblLogo);

            Label lblAltLogo = new Label
            {
                Text = "Dijital Kayıt Sistemi",
                Font = new Font("Segoe UI", 8F, FontStyle.Regular),
                ForeColor = Color.LightGray,
                Location = new Point(18, 50),
                AutoSize = true
            };
            panelSidebar.Controls.Add(lblAltLogo);

            // --- 2. HEADER (Üst Panel) ---
            panelHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 70,
                BackColor = Color.White
            };

            lblBaslik = new Label
            {
                Text = "Hasta Kayıt ve Poliklinik Yönetim Paneli",
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = renkYaziKoyu,
                Location = new Point(20, 20),
                AutoSize = true
            };
            panelHeader.Controls.Add(lblBaslik);

            // --- 3. ANA İÇERİK ALANI (Kalan Boşluğu Dolduracak) ---
            panelMainContent = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20),
                BackColor = renkAnaArkaPlan
            };

            // !!! CRITICAL: Kontrollerin forma eklenme sırası kaymayı önlemek için değiştirildi
            this.Controls.Add(panelMainContent);
            this.Controls.Add(panelHeader);
            this.Controls.Add(panelSidebar);

            // --- 4. KART: HASTA BİLGİLERİ GİRİŞ FORMU ---
            GroupBox gbHastaFormu = new GroupBox
            {
                Text = " Hasta Kayıt Formu ",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = renkYaziKoyu,
                Size = new Size(410, 620),
                Location = new Point(20, 15),
                BackColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            panelMainContent.Controls.Add(gbHastaFormu);

            int startX = 20, startY = 30, yGap = 58, labelGap = 18;
            Size inputSize = new Size(370, 26);

            // T.C. Kimlik No
            CreateFormLabel(gbHastaFormu, "T.C. Kimlik No:", startX, startY);
            txtTC = CreateTextBox(gbHastaFormu, startX, startY + labelGap, inputSize, 11);

            // Adı Soyadı
            CreateFormLabel(gbHastaFormu, "Ad Soyad:", startX, startY + yGap);
            txtAdSoyad = CreateTextBox(gbHastaFormu, startX, startY + yGap + labelGap, inputSize);

            // Telefon
            CreateFormLabel(gbHastaFormu, "Telefon:", startX, startY + (yGap * 2));
            txtTelefon = CreateTextBox(gbHastaFormu, startX, startY + (yGap * 2) + labelGap, inputSize);

            // E-Posta
            CreateFormLabel(gbHastaFormu, "E-Posta:", startX, startY + (yGap * 3));
            txtEposta = CreateTextBox(gbHastaFormu, startX, startY + (yGap * 3) + labelGap, inputSize);

            // Doğum Tarihi & Kan Grubu (Görseldeki gibi yan yana)
            CreateFormLabel(gbHastaFormu, "Doğum Tarihi:", startX, startY + (yGap * 4));
            dtpDogumTarihi = new DateTimePicker
            {
                Location = new Point(startX, startY + (yGap * 4) + labelGap),
                Size = new Size(175, 26),
                Format = DateTimePickerFormat.Short,
                Font = new Font("Segoe UI", 9.5F)
            };
            gbHastaFormu.Controls.Add(dtpDogumTarihi);

            CreateFormLabel(gbHastaFormu, "Kan Grubu:", startX + 195, startY + (yGap * 4));
            cmbKanGrubu = CreateComboBox(gbHastaFormu, startX + 195, startY + (yGap * 4) + labelGap, new Size(175, 26), new string[] { "A(Rh)+", "A(Rh)-", "B(Rh)+", "B(Rh)-", "AB(Rh)+", "AB(Rh)-", "0(Rh)+", "0(Rh)-" });

            // Cinsiyet
            CreateFormLabel(gbHastaFormu, "Cinsiyet:", startX, startY + (yGap * 5));
            cmbCinsiyet = CreateComboBox(gbHastaFormu, startX, startY + (yGap * 5) + labelGap, inputSize, new string[] { "Erkek", "Kadın" });

            // Poliklinik
            CreateFormLabel(gbHastaFormu, "Poliklinik Seçimi:", startX, startY + (yGap * 6));
            cmbPoliklinik = CreateComboBox(gbHastaFormu, startX, startY + (yGap * 6) + labelGap, inputSize, new string[] { "Göz Hastalıkları", "Dahiliye", "Kardiyoloji", "Kulak Burun Boğaz", "Nöroloji", "Ortopedi", "Pediatri (Çocuk)" });

            // İşlem Butonları (Görseldeki renk ve tasarıma göre)
            int btnY = 560;
            btnKaydet = CreateButton("Kaydet", startX, btnY, new Size(115, 36), Color.FromArgb(46, 204, 113));
            btnKaydet.Click += BtnKaydet_Click;
            gbHastaFormu.Controls.Add(btnKaydet);

            btnGuncelle = CreateButton("Güncelle", startX + 128, btnY, new Size(115, 36), Color.FromArgb(52, 152, 219));
            btnGuncelle.Click += BtnGuncelle_Click;
            gbHastaFormu.Controls.Add(btnGuncelle);

            btnSil = CreateButton("Sil", startX + 255, btnY, new Size(115, 36), Color.FromArgb(231, 76, 60));
            btnSil.Click += BtnSil_Click;
            gbHastaFormu.Controls.Add(btnSil);


            // --- 5. KART: POLİKLİNİK SIRA LİSTESİ ---
            GroupBox gbHastaListesi = new GroupBox
            {
                Text = " Poliklinik Sıra Listesi ",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = renkYaziKoyu,
                Size = new Size(580, 620), // Form genişliği ile dengelendi
                Location = new Point(450, 15),
                BackColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            panelMainContent.Controls.Add(gbHastaListesi);

            dgvHastalar = new DataGridView
            {
                Location = new Point(15, 25),
                Size = new Size(550, 575),
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                GridColor = renkKenarlik,
                ReadOnly = true
            };

            // Tablo Görsel Tasarım Ayarları
            dgvHastalar.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(43, 58, 74);
            dgvHastalar.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvHastalar.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            dgvHastalar.EnableHeadersVisualStyles = false;
            dgvHastalar.DefaultCellStyle.Font = new Font("Segoe UI", 9.5F);
            dgvHastalar.DefaultCellStyle.SelectionBackColor = Color.FromArgb(232, 244, 248);
            dgvHastalar.DefaultCellStyle.SelectionForeColor = renkYaziKoyu;
            dgvHastalar.RowTemplate.Height = 35;

            // Sütunlar
            dgvHastalar.Columns.Add("tc", "T.C. No");
            dgvHastalar.Columns.Add("adsoyad", "Adı Soyadı");
            dgvHastalar.Columns.Add("poliklinik", "Poliklinik");
            dgvHastalar.Columns.Add("kangrubu", "Kan G.");

            dgvHastalar.CellClick += dgvHastalar_CellClick;
            gbHastaListesi.Controls.Add(dgvHastalar);

            OrnekVeriYukle();
        }

        // --- TASARIM YARDIMCI METOTLARI ---

        private void CreateFormLabel(Control parent, string text, int x, int y)
        {
            Label lbl = new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(120, 130, 140),
                Location = new Point(x, y),
                AutoSize = true
            };
            parent.Controls.Add(lbl);
        }

        private TextBox CreateTextBox(Control parent, int x, int y, Size size, int maxLength = 32767)
        {
            TextBox txt = new TextBox
            {
                Location = new Point(x, y),
                Size = size,
                Font = new Font("Segoe UI", 10F),
                BorderStyle = BorderStyle.FixedSingle,
                MaxLength = maxLength
            };
            parent.Controls.Add(txt);
            return txt;
        }

        private ComboBox CreateComboBox(Control parent, int x, int y, Size size, string[] items)
        {
            ComboBox cmb = new ComboBox
            {
                Location = new Point(x, y),
                Size = size,
                Font = new Font("Segoe UI", 9.5F),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmb.Items.AddRange(items);
            if (cmb.Items.Count > 0) cmb.SelectedIndex = 0;
            parent.Controls.Add(cmb);
            return cmb;
        }

        private Button CreateButton(string text, int x, int y, Size size, Color backColor)
        {
            Button btn = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = size,
                BackColor = backColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, btn.Width, btn.Height, 5, 5)); // Yumuşak köşe kenarlığı
            return btn;
        }

        private void OrnekVeriYukle()
        {
            dgvHastalar.Rows.Add("12345678902", "Ahmet Yılmaz", "Kardiyoloji", "A(Rh)+");
            dgvHastalar.Rows.Add("98765432104", "Ayşe Demir", "Göz Hastalıkları", "0(Rh)-");
            dgvHastalar.Rows.Add("45612378956", "Mehmet Kaya", "Dahiliye", "B(Rh)+");
        }

        // --- EVENTLER ---

        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTC.Text) || string.IsNullOrWhiteSpace(txtAdSoyad.Text))
            {
                MessageBox.Show("Lütfen T.C. No ve Ad Soyad alanlarını boş bırakmayın.", "Eksik Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            dgvHastalar.Rows.Add(txtTC.Text, txtAdSoyad.Text, cmbPoliklinik.SelectedItem.ToString(), cmbKanGrubu.SelectedItem.ToString());
            FormuTemizle();
        }

        private void BtnGuncelle_Click(object sender, EventArgs e)
        {
            if (dgvHastalar.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvHastalar.SelectedRows[0];
                row.Cells[0].Value = txtTC.Text;
                row.Cells[1].Value = txtAdSoyad.Text;
                row.Cells[2].Value = cmbPoliklinik.SelectedItem.ToString();
                row.Cells[3].Value = cmbKanGrubu.SelectedItem.ToString();
                FormuTemizle();
            }
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
            if (dgvHastalar.SelectedRows.Count > 0)
            {
                dgvHastalar.Rows.RemoveAt(dgvHastalar.SelectedRows[0].Index);
                FormuTemizle();
            }
        }

        private void dgvHastalar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvHastalar.Rows[e.RowIndex];
                txtTC.Text = row.Cells[0].Value.ToString();
                txtAdSoyad.Text = row.Cells[1].Value.ToString();
                cmbPoliklinik.SelectedItem = row.Cells[2].Value.ToString();
                cmbKanGrubu.SelectedItem = row.Cells[3].Value.ToString();
            }
        }

        private void FormuTemizle()
        {
            txtTC.Clear();
            txtAdSoyad.Clear();
            txtTelefon.Clear();
            txtEposta.Clear();
            dtpDogumTarihi.Value = DateTime.Now;
        }
    }
}